import React, { useState, useEffect } from 'react';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
import { useNavigate } from 'react-router-dom';
function PersonTable() {
  const [data, setData] = useState([]);
  const URL = 'https://localhost:44374/api/PersonalInformation';
  //const URl = 'https://localhost:44374/api/AdditionalInformation';
  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  function handleDetails(e, i) {
    console.log(i);
    navigate('/details/' + i);
  }
  function handleEdit(e, i) {
    console.log(i);
    navigate('/edit/' + i);
  }

  function Delete(i) {
    const request = { method: 'DELETE' };
    fetch(URL + '/' + i, request)
      .then((response) => {
        return response.json();
      })
      .then((res) => {
        console.log('Delete Successful');
        fetchData();
      });
  }

  function handleDelete(e, i) {
    console.log('Delete Clicked' + i);

    confirmAlert({
      title: 'Confirm to Delete',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            Delete(i);
          },
        },
        {
          label: 'No',
          onClick: () => {
            //fetchData();
          },
        },
      ],
    });
  }

  function navCreate(e) {
    navigate('/create');
  }
  const fetchData = () => {
    fetch(URL)
      .then((res) => res.json())

      .then((response) => {
        const r = JSON.stringify(response);
        setData(JSON.parse(r));
        console.log('Response ' + r);
      });
  };

  return (
    <>
      <h3 style={{ marginTop: '20px' }}>Persons</h3>

      <Button
        style={{ marginTop: '15px', marginBottom: '15px' }}
        onClick={(e) => navCreate(e)}
      >
        Create
      </Button>

      <div>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th> </th>
              <th>UId</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Country</th>
              <th>ResearchInstitution</th>
              <th>VisitingFrom</th>
              <th>VisitingTo</th>
              <th>TotalExpense</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {data.map((item, i) => (
              <tr key={item.id}>
                <td>{i}</td>
                <td>{item.UID}</td>
                <td>{item.first_name}</td>
                <td>{item.last_name}</td>
                <td>{item.Country}</td>
                <td>{item.Institution}</td>
                <td>{item.Travel_Start_Date}</td>
                <td>{item.Travel_End_Date}</td>
                <td>{item.Total_Expenses}</td>
                <td>
                  <div>
                    <Button
                      variant="primary"
                      type="submit"
                      onClick={(e) => {
                        handleDetails(e, item.id);
                      }}
                    >
                      Details
                    </Button>

                    <> | </>
                    <Button
                      variant="warning"
                      type="submit"
                      onClick={(e) => {
                        handleEdit(e, item.id);
                      }}
                    >
                      Edit
                    </Button>

                    <> | </>
                    <Button
                      variant="danger"
                      type="submit"
                      onClick={(e) => {
                        handleDelete(e, item.id);
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </>
  );
}

export default PersonTable;
