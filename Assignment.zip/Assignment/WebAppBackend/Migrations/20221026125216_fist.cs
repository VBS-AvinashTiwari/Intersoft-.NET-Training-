﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebAppBackend.Migrations
{
    public partial class fist : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "additionalInfos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Applied_To_Other_Organization = table.Column<bool>(type: "bit", nullable: false),
                    Name_Of_Organization = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Other_Amount_Received = table.Column<bool>(type: "bit", nullable: false),
                    Additional_Comment = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_additionalInfos", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "expenseInfors",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Cost_Of_Airfare = table.Column<float>(type: "real", nullable: false),
                    Cost_Of_CareRental = table.Column<float>(type: "real", nullable: false),
                    Cost_of_Lodging = table.Column<float>(type: "real", nullable: false),
                    Cost_Of_OtherGroundTransportation = table.Column<float>(type: "real", nullable: false),
                    Cost_Of_Mileage = table.Column<float>(type: "real", nullable: false),
                    Description_Of_Other_Expenses = table.Column<float>(type: "real", nullable: false),
                    Total_Expenses = table.Column<float>(type: "real", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_expenseInfors", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "personalInfos",
                columns: table => new
                {
                    UID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    first_name = table.Column<string>(type: "nvarchar(20)", nullable: true),
                    last_name = table.Column<string>(type: "nvarchar(20)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    Address_1 = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    Address_2 = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    Country = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    State = table.Column<string>(type: "nvarchar(20)", nullable: true),
                    City = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    Zip_Code = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_personalInfos", x => x.UID);
                });

            migrationBuilder.CreateTable(
                name: "researchInfos",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Subject = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Institution = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Travel_Start_Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Travel_End_Date = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_researchInfos", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "additionalInfos");

            migrationBuilder.DropTable(
                name: "expenseInfors");

            migrationBuilder.DropTable(
                name: "personalInfos");

            migrationBuilder.DropTable(
                name: "researchInfos");
        }
    }
}
