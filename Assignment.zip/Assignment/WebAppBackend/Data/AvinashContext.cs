﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAppBackend.Models;

namespace WebAppBackend.Data
{
    public class AvinashContext:DbContext
    {
        public AvinashContext(DbContextOptions options) : base(options)
        {
        }
        public DbSet<AdditionalInfo> additionalInfos { get; set; }
        public DbSet<ExpenseInfo> expenseInfors { get; set; }
        public DbSet<PersonalInfo> personalInfos { get; set; }
        public DbSet<ResearchInfo> researchInfos { get; set; }
    }
}
