﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppBackend.Models
{
    public class ResearchInfo
    {

        [Key]
        public int Id { get; set; }
        public string Subject { get; set; }
        public string Institution { get; set; }
        public DateTime Travel_Start_Date { get; set; }
        public DateTime Travel_End_Date { get; set; }
    }
}
