﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppBackend.Models
{
    public class ExpenseInfo
    {
        [Key]
        public int ID { get; set; }
        public float Cost_Of_Airfare { get; set; }

        public float Cost_Of_CareRental { get; set; }
        public float Cost_of_Lodging { get; set; }
        public float Cost_Of_OtherGroundTransportation { get; set; }
        public float Cost_Of_Mileage { get; set; }
        public float Description_Of_Other_Expenses { get; set; }

        public float Total_Expenses { get; set; }
    }
}
