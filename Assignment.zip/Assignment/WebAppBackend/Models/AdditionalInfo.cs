﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppBackend.Models
{
    public class AdditionalInfo
    {
        [Key]
        public int Id { get; set; }
        public Boolean Applied_To_Other_Organization { get; set; }
        public string Name_Of_Organization { get; set; }
        public Boolean Other_Amount_Received { get; set; }
        public string Additional_Comment { get; set; }
    }
}
