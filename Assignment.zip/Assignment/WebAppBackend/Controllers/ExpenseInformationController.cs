﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using WebAppBackend.Models;

namespace WebAppBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExpenseInformationController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public ExpenseInformationController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
                            select Id, Cost_Of_Airfare, Cost_Of_CareRental,Cost_of_Lodging,Cost_Of_OtherGroundTransportation, 
                            Cost_Of_Mileage,Description_Of_Other_Expenses, Total_Expenses
                            from
                            dbo.expenseInfors
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }
        [HttpPost]
        public JsonResult Post(ExpenseInfo expenseInfo)
        {
            string query = @"
                            insert into dbo.expenseInfors( Cost_Of_Airfare ,Cost_Of_CareRental,Cost_of_Lodging,
                             Cost_Of_OtherGroundTransportation,Cost_Of_Mileage,Description_Of_Other_Expenses,Total_Expenses)
                              values
                             ( @Cost_Of_Airfare , @Cost_Of_CareRental, @Cost_of_Lodging,
                             @Cost_Of_OtherGroundTransportation, @Cost_Of_Mileage, @Description_Of_Other_Expenses, @Total_Expenses)";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    
                    myCommand.Parameters.AddWithValue("@Cost_Of_Airfare", expenseInfo.Cost_Of_Airfare);
                    myCommand.Parameters.AddWithValue("@Cost_Of_CareRental", expenseInfo.Cost_Of_CareRental);
                    myCommand.Parameters.AddWithValue("@Cost_of_Lodging", expenseInfo.Cost_of_Lodging);
                    myCommand.Parameters.AddWithValue("@Cost_Of_OtherGroundTransportation", expenseInfo.Cost_Of_OtherGroundTransportation);
                    myCommand.Parameters.AddWithValue("@Cost_Of_Mileage", expenseInfo.Cost_Of_Mileage);
                    myCommand.Parameters.AddWithValue("@Description_Of_Other_Expenses", expenseInfo.Description_Of_Other_Expenses);
                    myCommand.Parameters.AddWithValue("@Total_Expenses", expenseInfo.Total_Expenses);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Added Successfully");

        }

        [HttpPut]
        public JsonResult Put(ExpenseInfo expenseInfo)
        {
            string query = @"
                           update dbo.expenseInfors
                           Cost_Of_Airfare= @Cost_Of_Airfare,
                           Cost_Of_CareRental = @Cost_Of_CareRental,
                           Cost_of_Lodging = @Cost_of_Lodging,
                           Cost_Of_OtherGroundTransportation = @Cost_Of_OtherGroundTransportation,
                           Cost_Of_Mileage=@Cost_Of_Mileage,
                           Description_Of_Other_Expenses=@Description_Of_Other_Expenses,
                           Total_Expenses=@Total_Expenses
                            where ID=@ID";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Id", expenseInfo.ID);
                    myCommand.Parameters.AddWithValue("@Cost_Of_Airfare", expenseInfo.Cost_Of_Airfare);
                    myCommand.Parameters.AddWithValue("@Cost_Of_CareRental", expenseInfo.Cost_Of_CareRental);
                    myCommand.Parameters.AddWithValue("@Cost_of_Lodging", expenseInfo.Cost_of_Lodging);
                    myCommand.Parameters.AddWithValue("@Cost_Of_OtherGroundTransportation", expenseInfo.Cost_Of_OtherGroundTransportation);
                    myCommand.Parameters.AddWithValue("@Cost_Of_Mileage", expenseInfo.Cost_Of_Mileage);
                    myCommand.Parameters.AddWithValue("@Description_Of_Other_Expenses", expenseInfo.Description_Of_Other_Expenses);
                    myCommand.Parameters.AddWithValue("@Total_Expenses", expenseInfo.Total_Expenses);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Updated Successfully");

        }
        [HttpDelete("{ID}")]
        public JsonResult Delete(int ID)
        {
            string query = @"
                            delete from dbo.expenseInfors
                            where ID = @ID
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@ID", ID);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Deleted Successfully");
        }





    }

}
