﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using WebAppBackend.Data;
using WebAppBackend.Models;

namespace WebAppBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResearchInformationController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public ResearchInformationController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
                             select Id, Subject, Institution, Travel_Start_Date, Travel_End_Date from
                             dbo.researchInfos
                             ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }
        [HttpPost]
        public JsonResult Post(ResearchInfo researchInfo)
        {
            string query = @"
                             insert into dbo.researchInfos values ( Subject, Institution, Travel_Start_Date, Travel_End_Date)
                             values
                             (@Id, @Subject, @Institution, @Travel_Start_Date, @Travel_End_Date)";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    
                    myCommand.Parameters.AddWithValue("@Subject", researchInfo.Subject);
                    myCommand.Parameters.AddWithValue("@Institution", researchInfo.Institution);
                    myCommand.Parameters.AddWithValue("@Travel_Start_Date", researchInfo.Travel_Start_Date);
                    myCommand.Parameters.AddWithValue("@Travel_End_Date", researchInfo.Travel_End_Date);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Added Successfully");

        }

        [HttpPut]
        public JsonResult Put(ResearchInfo researchInfo)
        {
            string query = @"
                            update dbo.researchInfos 
                            Subject = @Subject,
                            Institution = @Institution,
                            Travel_Start_Date = @Travel_Start_Date,
                            Travel_End_Date=@Travel_End_Date
                             where Id=@Id";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Id", researchInfo.Id);
                    myCommand.Parameters.AddWithValue("@Subject", researchInfo.Subject);
                    myCommand.Parameters.AddWithValue("@Institution", researchInfo.Institution);
                    myCommand.Parameters.AddWithValue("@Travel_Start_Date", researchInfo.Travel_Start_Date);
                    myCommand.Parameters.AddWithValue("Travel_End_Date", researchInfo.Travel_End_Date);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Updated Successfully");

        }
        [HttpDelete("{Id}")]
        public JsonResult Delete(int Id)
        {
            string query = @"
                             delete from dbo.researchInfos
                             where Id = @Id
                             ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Id", Id);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Deleted Successfully");
        }



    }

}



