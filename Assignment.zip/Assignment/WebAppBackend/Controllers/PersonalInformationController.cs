﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using WebAppBackend.Models;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace WebAppBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonalInformationController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public PersonalInformationController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
                           select UID, first_name, last_name, Email, 
                            Address_1, Address_2, Country, State, City, Zip_Code from
                            dbo.personalInfos
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }
        [HttpPost]
        public JsonResult Post(PersonalInfo personalInfo)
        {
            string query = @"
                            insert into dbo.personalInfos(first_name, last_name, Email, Address_1, Address_2, Country, State, City, Zip_Code)
                             values
                             (@first_name, @last_name, @Email, @Address_1, @Address_2, @Country, @State, @City, @Zip_Code)
                             ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    
                    //myCommand.Parameters.AddWithValue("@first_name nvarchar(20)", personalInfo.first_name);
                    myCommand.Parameters.Add("@first_name", SqlDbType.VarChar).Value = personalInfo.first_name;
                   // myCommand.Parameters.AddWithValue("@last_name nvarchar(20)", personalInfo.last_name);
                    myCommand.Parameters.Add("@last_name", SqlDbType.VarChar).Value = personalInfo.last_name;
                    //myCommand.Parameters.AddWithValue ("@Email nvarchar(100)", personalInfo.Email);
                    myCommand.Parameters.Add("@Email", SqlDbType.VarChar).Value = personalInfo.Email;
                    //myCommand.Parameters.AddWithValue("@Address_1", personalInfo.Address_1);
                    myCommand.Parameters.Add("@Address_1", SqlDbType.VarChar).Value = personalInfo.Address_1;
                    //myCommand.Parameters.AddWithValue("@Address_2", personalInfo.Address_2);
                    myCommand.Parameters.Add("@Address_2", SqlDbType.VarChar).Value = personalInfo.Address_2;
                   // myCommand.Parameters.AddWithValue("@Country", personalInfo.Country);
                    myCommand.Parameters.Add("@Country", SqlDbType.VarChar).Value = personalInfo.Country;
                    //myCommand.Parameters.AddWithValue("@State", personalInfo.State);
                    myCommand.Parameters.Add("@State", SqlDbType.VarChar).Value = personalInfo.State;
                   // myCommand.Parameters.AddWithValue("@City", personalInfo.City);
                    myCommand.Parameters.Add("@City", SqlDbType.VarChar).Value = personalInfo.City;
                    myCommand.Parameters.AddWithValue("@Zip_Code", personalInfo.Zip_Code);
                    //myCommand.Parameters.Add("@Zip_Code", SqlDbType.VarChar).Value = personalInfo.Zip_Code;
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Added Successfully");

        }

        [HttpPut]
        public JsonResult Put(PersonalInfo personalInfo)
        {
            string query = @"
                           update dbo.personalInfos 
                          set first_name = @first_name,
                           last_name = @last_name,
                           Email = @Email,
                           Address_1=@Address_1,
                           Address_2=@Address_2,
                           Country=@Country,
                           State=@State,
                           City=@City,
                           Zip_Code=@Zip_Code
                            where UID=@UID";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@UId", personalInfo.UID);
                    myCommand.Parameters.AddWithValue("@first_name", personalInfo.first_name);
                    myCommand.Parameters.AddWithValue("@last_name", personalInfo.last_name);
                    myCommand.Parameters.AddWithValue("@Email", personalInfo.Email);
                    myCommand.Parameters.AddWithValue("@Address_1", personalInfo.Address_1);
                    myCommand.Parameters.AddWithValue("@Address_2", personalInfo.Address_2);
                    myCommand.Parameters.AddWithValue("@Country", personalInfo.Country);
                    myCommand.Parameters.AddWithValue("@State", personalInfo.State);
                    myCommand.Parameters.AddWithValue("@City", personalInfo.City);
                    myCommand.Parameters.AddWithValue("@Zip_Code", personalInfo.Zip_Code);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Updated Successfully");

        }
        [HttpDelete("{UID}")]
        public JsonResult Delete(int UID)
        {
            string query = @"
                            delete from dbo.personalInfos
                            where UID = @UID
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@UID", UID);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Deleted Successfully");
        }



    }

}
