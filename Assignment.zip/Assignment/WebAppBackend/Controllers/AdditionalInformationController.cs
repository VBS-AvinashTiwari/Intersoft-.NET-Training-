﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using WebAppBackend.Models;

namespace WebAppBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdditionalInformationController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public AdditionalInformationController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public JsonResult AdditionalGet()
        {
            string query = @"
                            select Id, Applied_To_Other_Organization,Name_Of_Organization,Other_Amount_Received,Additional_Comment from
                            dbo.additionalInfos
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }





        [HttpPost]
        public JsonResult AdditionalPost(AdditionalInfo additionalInfo)
        {
            string query = @"
                             insert into dbo.additionalInfos( Applied_To_Other_Organization, Name_Of_Organization, Other_Amount_Received, Additional_Comment )
                             values
                             ( @Applied_To_Other_Organization, @Name_Of_Organization, @Other_Amount_Received, @Additional_Comment )
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                   
                    myCommand.Parameters.AddWithValue("@Name_Of_Organization", additionalInfo.Name_Of_Organization);
                    myCommand.Parameters.AddWithValue("@Applied_To_Other_Organization", additionalInfo.Applied_To_Other_Organization);
                    myCommand.Parameters.AddWithValue("@Other_Amount_Received", additionalInfo.Other_Amount_Received);
                    myCommand.Parameters.AddWithValue("@Additional_Comment", additionalInfo.Additional_Comment);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Added Successfully");

        }

        [HttpPut]
        public JsonResult AdditionalPut(AdditionalInfo additionalInfo)
        {
            string query = @"
                           update dbo.additionalInfos
                           set Name_Of_Organization= @Name_Of_Organization,
                           Applied_To_Other_Organization = @Applied_To_Other_Organization,
                           Other_Amount_Received = @Other_Amount_Received,
                           Additional_Comment = @Additional_Comment
                            where Id=@Id";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Id", additionalInfo.Id);
                    myCommand.Parameters.AddWithValue("@Name_Of_Organization", additionalInfo.Name_Of_Organization);
                    myCommand.Parameters.AddWithValue("@Applied_To_Other_Organization", additionalInfo.Applied_To_Other_Organization);
                    myCommand.Parameters.AddWithValue("@Other_Amount_Received", additionalInfo.Other_Amount_Received);
                    myCommand.Parameters.AddWithValue("@Additional_Comment", additionalInfo.Additional_Comment);


                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Updated Successfully");
        }

        [HttpDelete("{Id}")]
        public JsonResult AdditionalDelete(int Id)
        {
            string query = @"
                           delete from dbo.additionalInfos
                            where ID=@Id
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Id", Id);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Deleted Successfully");
        }

      /*  //ExpenseInformation

        [HttpGet]
        public JsonResult ExpenseGet()
        {
            string query = @"
                            select Id, Cost_Of_Airfare, Cost_Of_CareRental,Cost_of_Lodging,Cost_Of_OtherGroundTransportation, 
                            Cost_Of_Mileage,Description_Of_Other_Expenses, Total_Expenses
                            from
                            dbo.expenseInfors
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }

        [HttpPost]
        public JsonResult ExpensePost(ExpenseInfo expenseInfo)
        {
            string query = @"
                            insert into dbo.expenseInfors( Cost_Of_Airfare ,Cost_Of_CareRental,Cost_of_Lodging,
                             Cost_Of_OtherGroundTransportation,Cost_Of_Mileage,Description_Of_Other_Expenses,Total_Expenses)
                              values
                             ( @Cost_Of_Airfare , @Cost_Of_CareRental, @Cost_of_Lodging,
                             @Cost_Of_OtherGroundTransportation, @Cost_Of_Mileage, @Description_Of_Other_Expenses, @Total_Expenses)";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {

                    myCommand.Parameters.AddWithValue("@Cost_Of_Airfare", expenseInfo.Cost_Of_Airfare);
                    myCommand.Parameters.AddWithValue("@Cost_Of_CareRental", expenseInfo.Cost_Of_CareRental);
                    myCommand.Parameters.AddWithValue("@Cost_of_Lodging", expenseInfo.Cost_of_Lodging);
                    myCommand.Parameters.AddWithValue("@Cost_Of_OtherGroundTransportation", expenseInfo.Cost_Of_OtherGroundTransportation);
                    myCommand.Parameters.AddWithValue("@Cost_Of_Mileage", expenseInfo.Cost_Of_Mileage);
                    myCommand.Parameters.AddWithValue("@Description_Of_Other_Expenses", expenseInfo.Description_Of_Other_Expenses);
                    myCommand.Parameters.AddWithValue("@Total_Expenses", expenseInfo.Total_Expenses);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Added Successfully");

        }

        [HttpPut]
        public JsonResult ExpensePut(ExpenseInfo expenseInfo)
        {
            string query = @"
                           update dbo.expenseInfors
                           Cost_Of_Airfare= @Cost_Of_Airfare,
                           Cost_Of_CareRental = @Cost_Of_CareRental,
                           Cost_of_Lodging = @Cost_of_Lodging,
                           Cost_Of_OtherGroundTransportation = @Cost_Of_OtherGroundTransportation,
                           Cost_Of_Mileage=@Cost_Of_Mileage,
                           Description_Of_Other_Expenses=@Description_Of_Other_Expenses,
                           Total_Expenses=@Total_Expenses
                            where ID=@ID";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Id", expenseInfo.ID);
                    myCommand.Parameters.AddWithValue("@Cost_Of_Airfare", expenseInfo.Cost_Of_Airfare);
                    myCommand.Parameters.AddWithValue("@Cost_Of_CareRental", expenseInfo.Cost_Of_CareRental);
                    myCommand.Parameters.AddWithValue("@Cost_of_Lodging", expenseInfo.Cost_of_Lodging);
                    myCommand.Parameters.AddWithValue("@Cost_Of_OtherGroundTransportation", expenseInfo.Cost_Of_OtherGroundTransportation);
                    myCommand.Parameters.AddWithValue("@Cost_Of_Mileage", expenseInfo.Cost_Of_Mileage);
                    myCommand.Parameters.AddWithValue("@Description_Of_Other_Expenses", expenseInfo.Description_Of_Other_Expenses);
                    myCommand.Parameters.AddWithValue("@Total_Expenses", expenseInfo.Total_Expenses);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Updated Successfully");

        }
        [HttpDelete("{ID}")]
        public JsonResult ExpenseDelete(int ID)
        {
            string query = @"
                            delete from dbo.expenseInfors
                            where ID = @ID
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@ID", ID);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Deleted Successfully");
        }

        //PersonalInformation

       [HttpGet]
        public JsonResult PersonalGet()
        {
            string query = @"
                           select UID, first_name, last_name, Email, 
                            Address_1, Address_2, Country, State, City, Zip_Code from
                            dbo.personalInfos
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }
        [HttpPost]
        public JsonResult PersonalPost(PersonalInfo personalInfo)
        {
            string query = @"
                            insert into dbo.personalInfos(first_name, last_name, Email, Address_1, Address_2, Country, State, City, Zip_Code)
                             values
                             (@first_name, @last_name, @Email, @Address_1, @Address_2, @Country, @State, @City, @Zip_Code)
                             ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {

                    //myCommand.Parameters.AddWithValue("@first_name nvarchar(20)", personalInfo.first_name);
                    myCommand.Parameters.Add("@first_name", SqlDbType.VarChar).Value = personalInfo.first_name;
                    // myCommand.Parameters.AddWithValue("@last_name nvarchar(20)", personalInfo.last_name);
                    myCommand.Parameters.Add("@last_name", SqlDbType.VarChar).Value = personalInfo.last_name;
                    //myCommand.Parameters.AddWithValue ("@Email nvarchar(100)", personalInfo.Email);
                    myCommand.Parameters.Add("@Email", SqlDbType.VarChar).Value = personalInfo.Email;
                    //myCommand.Parameters.AddWithValue("@Address_1", personalInfo.Address_1);
                    myCommand.Parameters.Add("@Address_1", SqlDbType.VarChar).Value = personalInfo.Address_1;
                    //myCommand.Parameters.AddWithValue("@Address_2", personalInfo.Address_2);
                    myCommand.Parameters.Add("@Address_2", SqlDbType.VarChar).Value = personalInfo.Address_2;
                    // myCommand.Parameters.AddWithValue("@Country", personalInfo.Country);
                    myCommand.Parameters.Add("@Country", SqlDbType.VarChar).Value = personalInfo.Country;
                    //myCommand.Parameters.AddWithValue("@State", personalInfo.State);
                    myCommand.Parameters.Add("@State", SqlDbType.VarChar).Value = personalInfo.State;
                    // myCommand.Parameters.AddWithValue("@City", personalInfo.City);
                    myCommand.Parameters.Add("@City", SqlDbType.VarChar).Value = personalInfo.City;
                    //myCommand.Parameters.AddWithValue("@Zip_Code", personalInfo.Zip_Code);
                    myCommand.Parameters.Add("@Zip_Code", SqlDbType.VarChar).Value = personalInfo.Zip_Code;
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Added Successfully");

        }

        [HttpPut]
        public JsonResult PersonalPut(PersonalInfo personalInfo)
        {
            string query = @"
                           update dbo.personalInfos 
                          set first_name = @first_name,
                           last_name = @last_name,
                           Email = @Email,
                           Address_1=@Address_1,
                           Address_2=@Address_2,
                           Country=@Country,
                           State=@State,
                           City=@City,
                           Zip_Code=@Zip_Code
                            where UID=@UID";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@UId", personalInfo.UID);
                    myCommand.Parameters.AddWithValue("@first_name", personalInfo.first_name);
                    myCommand.Parameters.AddWithValue("@last_name", personalInfo.last_name);
                    myCommand.Parameters.AddWithValue("@Email", personalInfo.Email);
                    myCommand.Parameters.AddWithValue("@Address_1", personalInfo.Address_1);
                    myCommand.Parameters.AddWithValue("@Address_2", personalInfo.Address_2);
                    myCommand.Parameters.AddWithValue("@Country", personalInfo.Country);
                    myCommand.Parameters.AddWithValue("@State", personalInfo.State);
                    myCommand.Parameters.AddWithValue("@City", personalInfo.City);
                    myCommand.Parameters.AddWithValue("@Zip_Code", personalInfo.Zip_Code);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Updated Successfully");

        }
        [HttpDelete("{UID}")]
        public JsonResult PersonalDelete(int UID)
        {
            string query = @"
                            delete from dbo.personalInfos
                            where UID = @UID
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@UID", UID);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Deleted Successfully");
        }

        //ResearchInformation

       *//*  [HttpGet("{id}")]
        public JsonResult ResearchGet(int id)
        {
            string query = @"
                             select Id, Subject, Institution, Travel_Start_Date, Travel_End_Date from
                             dbo.researchInfos
                             ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }*//*
        [HttpPost]
        public JsonResult ResearchPost(ResearchInfo researchInfo)
        {
            string query = @"
                             insert into dbo.researchInfos values ( Subject, Institution, Travel_Start_Date, Travel_End_Date)
                             values
                             (@Id, @Subject, @Institution, @Travel_Start_Date, @Travel_End_Date)";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {

                    myCommand.Parameters.AddWithValue("@Subject", researchInfo.Subject);
                    myCommand.Parameters.AddWithValue("@Institution", researchInfo.Institution);
                    myCommand.Parameters.AddWithValue("@Travel_Start_Date", researchInfo.Travel_Start_Date);
                    myCommand.Parameters.AddWithValue("@Travel_End_Date", researchInfo.Travel_End_Date);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Added Successfully");

        }

        [HttpPut]
        public JsonResult ResearchPut(ResearchInfo researchInfo)
        {
            string query = @"
                            update dbo.researchInfos 
                            Subject = @Subject,
                            Institution = @Institution,
                            Travel_Start_Date = @Travel_Start_Date,
                            Travel_End_Date=@Travel_End_Date
                             where Id=@Id";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Id", researchInfo.Id);
                    myCommand.Parameters.AddWithValue("@Subject", researchInfo.Subject);
                    myCommand.Parameters.AddWithValue("@Institution", researchInfo.Institution);
                    myCommand.Parameters.AddWithValue("@Travel_Start_Date", researchInfo.Travel_Start_Date);
                    myCommand.Parameters.AddWithValue("Travel_End_Date", researchInfo.Travel_End_Date);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Updated Successfully");

        }
        [HttpDelete("{Id}")]
        public JsonResult ResearchDelete(int Id)
        {
            string query = @"
                             delete from dbo.researchInfos
                             where Id = @Id
                             ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Id", Id);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult("Deleted Successfully");
        }*/

    }

    }

