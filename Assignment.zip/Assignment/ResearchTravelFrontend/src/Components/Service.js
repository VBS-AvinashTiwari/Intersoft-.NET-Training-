import axios from 'axios';

const USER_REST_URL = 'https://localhost:44374/api/AdditionalInformation'

class Service {
    getUser(){
       return axios.get( USER_REST_URL);
    }
}
export default new Service();