import React, { Component } from 'react'
import Service from './Service'

export default class user extends Component {

    constructor(props){
        super(props)
        this.state={
            user:[]
        }
    }

componentDidMount(){
    Service.getUser().then((res)=>{
        this.setState({user:res.data})
    });

}

  render() {
    return (
      <div>
        <h1>Additional Information</h1>
        <table className='table table-sprit'>
            <thead>
                <tr>
                    <td>id</td>
                    <td>first_name</td>
                    <td>city</td>
                   
                </tr>
            </thead>
            <tbody>
                {
                    this.state.user.map(
                        user =>
                        <tr key={user.Id}>
                            <td>{user.Applied_To_Other_Organization}</td>
                            <td>{user.Name_Of_Organization}</td>
                            <td>{user.Other_Amount_Received}</td>
                            <td>{user.Additional_Comment}</td>

                        </tr>
                        
                    )
                }
            </tbody>

        </table>
      </div>
    )
  }
}