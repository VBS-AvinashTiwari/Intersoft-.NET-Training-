import logo from './logo.svg';
import './App.css';
import Form from './Components/Form';
import User from './Components/User';


function App() {
  return (
    <div className="App">
    <Form />
    <User/>
    </div>
  );
}

export default App;
