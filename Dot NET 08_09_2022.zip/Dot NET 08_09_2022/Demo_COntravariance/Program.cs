﻿using System;

namespace Demo_COntravariance
{
    class Program
    {
        static void Setobject(object val1) { }
        static void SetString(string val2) { }

        
        static void Main(string[] args)
        {
            Console.WriteLine("Contravarance delegates reverses the covariance functionality");

            Action<string> del1 = Setobject; //indexer-built generic type delegates
            // here it is allowing a method that parameter types less derived than
            // what is sepecified in the delegate
            
        }
    }
}
