﻿using System;
using System.Collections.Generic;

namespace DEmo_Enumerator_and_IEnumerable
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working wiht IEnumerable");
            List<String> Month = new List<string>();
            Month.Add("Jan");
            Month.Add("Feb");
            Month.Add("Mar");

            //creating IEnumerable string 
            IEnumerable<String> iEnumerableofstring = Month;
            // Using Ienumerable Object 

            foreach (string ALLMonths in iEnumerableofstring)
            {
                Console.WriteLine(ALLMonths);
            }
            //creating IEnumerator of string 
            IEnumerator<string> iEnumeratorOfstring = Month.GetEnumerator();
            //Displaying  all the item from IEnumerator Object

            while (iEnumeratorOfstring.MoveNext()) ;
            {
                Console.WriteLine(iEnumeratorOfstring.Current);
            }
            // Both interface helps us in looping thorugh the collection

          
            


           
        }
    }
}
