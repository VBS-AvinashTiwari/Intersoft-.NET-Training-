﻿using System;


namespace Demo_Action_Delegate
{
    class Program
    {
        public static void Display(string message)
        {
            Console.WriteLine("Here we are instantiating Action(<T> delegates instead of explicityly defining a new delegates ");
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Action Delegate Working");


            Action<string> messagetargret;
            if (Environment.GetCommandLineArgs().Length >1)
            {
                messagetargret = Display;

            }
            else
            {
                messagetargret = Console.WriteLine;
                messagetargret("Hello world - This is the elese part of the condition");
            }
            
           
                
        }
    }
}
