﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo_Equality_Value_Ref
{
    class Member
    {
        public string Name { get; set; }
        public string Address { get; set; }
         public int Id { get; set; }
    }
}
