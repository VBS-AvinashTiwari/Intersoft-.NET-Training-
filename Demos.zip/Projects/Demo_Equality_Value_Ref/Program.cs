﻿using System;

namespace Demo_Equality_Value_Ref
{
    public struct Mystruct
    {
        public int Id { get; set; }

        public string name { get; set; }
    };
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Equality in C#");

            Member Obj1 = new Member { Id = 1, Name = " Avinash", Address = " Noida" };
            Member Obj2 = new Member { Id = 2, Name = "Gaurav", Address = "Gorakhpur" };
            Member OBJ3 = Obj2;
            Console.WriteLine("Lets check if two object have same or unique values:\n");

            Console.WriteLine(Obj1==Obj2);

            Console.WriteLine(Obj1.Equals(Obj2));

            Console.WriteLine(System.Object.ReferenceEquals(Obj1,Obj2));

            Console.WriteLine(Obj1=OBJ3);
            Console.WriteLine(Obj1.Equals(OBJ3));
            Console.WriteLine(System.Object.ReferenceEquals(Obj1,OBJ3));

            Obj1 = Obj2;

            Console.WriteLine("lETS CHECK IS TWO OBJECT HAVE SAME OR UNIQUE VALUES:\n");


            Console.WriteLine("Implementing value type equality using structure..!!!");

            Mystruct mystruct1 = new Mystruct { Id = 1, name = "Sachin" };

            Mystruct mystruct2 = new Mystruct { Id = 1, name = "saurav" };

            Console.WriteLine("Comparing has code");
            Console.WriteLine(Obj1.GetHashCode());
            Console.WriteLine(Obj2.GetHashCode());

            Console.WriteLine(System.Object.ReferenceEquals(mystruct1,mystruct2));

            Console.WriteLine(mystruct1.Equals(mystruct2));
        }
    }
}
