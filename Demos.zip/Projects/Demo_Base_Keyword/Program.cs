﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Base_Keyword
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("");
            Dog ginger = new Dog();
            ginger.showcolor();

            ginger.speak();// we are referring child class speak()


        }
    }
}
