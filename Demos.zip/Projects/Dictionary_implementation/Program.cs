﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary_implementation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dictionary Implementaion");
            Dictionary<String, Int16> AuthorList = new Dictionary<String, Int16>();
            AuthorList.Add("Avinash", 21);
            AuthorList.Add("Abhishek", 23);
            AuthorList.Add("Gaurav", 12);

            Dictionary<String, float> PriceList = new Dictionary<String, float>();
            PriceList.Add("Tea", 3.25f);
            PriceList.Add("Juice", 2.76f);
            PriceList.Add("Milk", 1.15f);

            foreach (KeyValuePair<string, Int16> item in AuthorList)
            {
                Console.WriteLine($"Name: {item.Key}, Value: {item.Value}");

            }
            //Remove an element
            AuthorList.Remove("Avinash");
            foreach (KeyValuePair<string, Int16> item in AuthorList)
            {
                Console.WriteLine($"Name: {item.Key}, Value: {item.Value}");

            }
            if (!AuthorList.ContainsKey("Avinash"))
            {
                AuthorList["Avinash"] = 20;
            }

            if (!AuthorList.ContainsValue(12))
            {
                Console.WriteLine("Item found");
            }

            //Clearing Collection
            Console.WriteLine("Count:" + AuthorList.Count);
            AuthorList.Clear();

            Console.WriteLine("Count:" + AuthorList.Count);
        }
    }
}
