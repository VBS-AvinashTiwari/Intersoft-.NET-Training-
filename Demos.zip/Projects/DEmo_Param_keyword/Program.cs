﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
//using Newtonsoft.Json;
namespace Demo_Param_keyword
{
    class Program
    {
        public void sk(params object[] ak)
        {
            foreach (var item in ak)
            {
                Console.WriteLine(item);
            }
        }
        static void Main(string[] args)
        {
            Program p1 = new Program();
            p1.sk("Avinash", 21, "avianshtiwari72771@gmail.com", "Gorakhpur");
        }
    }
}
