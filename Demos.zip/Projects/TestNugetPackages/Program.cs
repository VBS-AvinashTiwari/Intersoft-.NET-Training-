﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestNugetPackages;

namespace TestNugetPackages
{
    class Program
    {
        static void Main(string[] args)
        {
            
        
        }
    }
}
