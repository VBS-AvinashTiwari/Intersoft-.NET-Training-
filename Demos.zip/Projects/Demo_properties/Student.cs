﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_properties
{
    internal class Student { 


        private string[] names = new string[25];
         public string this[int i]
    {
        get { return names [i]; }
        set { names [i] = value; }
    }
        public long AadharCardNo
        {
            get { return 370264992468; }
        }
        public int ID { get; set; }
        private String Facebooklink;
        private string name;
        public String Name
        {
            get { return name; }
            set { name = value; }
        }

    }
}
