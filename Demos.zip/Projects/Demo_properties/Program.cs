﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_properties
{
    internal class Program
    {
        private static int i;

        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Properties");

            Student newStudent = new Student();
            newStudent.ID = 1;
            newStudent.Name = "Avinash";


            Console.WriteLine($" Stundet ID: {newStudent.ID} & Student Name:{newStudent.Name}, AadharCardNo:{newStudent.AadharCardNo}");

            newStudent[0] = "yami";
            newStudent[1] = "peter";
            newStudent[2] = "Gautam";
            for (int i = 0; i < 10; i++) 
            {
                Console.WriteLine(newStudent[i]);
            }

        }
    }
}
