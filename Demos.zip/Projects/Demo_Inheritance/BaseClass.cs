﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Inheritance
{
    internal class BaseClass
    {
        public string name;
        public string subject;

        public void read(string name, string subject)
        {
            this.name = name;
            this.subject = subject;
            Console.WriteLine($"I am {name} and my subject is {subject}");
        }
    }
    class child : BaseClass
    {
        public child ()
        {
            Console.WriteLine("this is my Child classs !!!!");
        }
    }
}
