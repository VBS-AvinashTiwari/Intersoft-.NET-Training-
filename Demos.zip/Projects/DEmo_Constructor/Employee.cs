﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEmo_Constructor
{
    class Employee
    {
        public string name;
        public string dept;
        public Employee()
        {
            dept = "Training & development";

        }
        public Employee (String name, string dept)
        {
            this.name = name;
            this.dept = dept;
        }


    }
}
