﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEmo_Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-------------implementing constructor");
            Employee Emp1 = new Employee();
            Console.WriteLine(Emp1.dept);
            Employee Emp2 = new Employee();
            Console.WriteLine(Emp2.dept);
            Employee Emp3 = new Employee("virat", "media and commucnication" );
            Console.WriteLine($" Employee 3 is {Emp3.name} and its dept is {Emp3.dept}");

        }
    }
}
