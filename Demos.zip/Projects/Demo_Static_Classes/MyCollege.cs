﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo_Static_Classes
{
    static class MyCollege
    {
        public static string Collegename;
        public static string CollegeAddress;
        public static string CollegeCity;

        public static string EstablishmentYear { get; set; }
        
        static MyCollege()
        {
            Collegename = "IEC - CET";
            CollegeAddress = "Knowledgepark-3";
            CollegeCity = "Gr.Noida";
        }

    }
}
