﻿using System;

namespace Demo_Static_Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            // we dont need to create object
            // static functions can be called from other fucntions directly
            Console.WriteLine("Static classess in c#");
            Console.WriteLine(MyCollege.Collegename + "\n" + MyCollege.CollegeAddress + "\n" + MyCollege.CollegeCity);
            MyCollege.EstablishmentYear = "1998";
            Console.WriteLine(MyCollege.EstablishmentYear + ":is the year of Establishment");
        }
    }
}
