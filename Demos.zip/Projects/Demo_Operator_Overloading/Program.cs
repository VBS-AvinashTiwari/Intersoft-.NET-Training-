﻿using System;

namespace Demo_Operator_Overloading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Operator overloading demo!!!!");
            Calculator calc1 = new Calculator(25, -55);
          
                calc1 = -calc1;

                calc1.Print();

            Calculator C1 = new Calculator(1, 2);
            Calculator c2 = new Calculator(3, 4);
            Calculator c3 = new Calculator(0, 0);
            Console.WriteLine("c1");
            C1.Print();
            Console.WriteLine("c2");
            c2.Print();
            c3 = C1 + c2;
            c3.Print();
            


        }
    }
}
