﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo_Operator_Overloading
{
    class Calculator
    {
        public int number1, number2;
        public Calculator(int num1, int num2)
        {
            number1 = num1;
            number2 = num2;
        }

        public Calculator()
        {
        }

        public static Calculator operator -(Calculator c1)
        {
            c1.number1 = -c1.number1;
            c1.number2 = -c1.number2;
              return c1;
        }

        public static Calculator operator + (Calculator calc1, Calculator calc2)
        {
            Calculator c = new Calculator(0,0);
            c.number1 = calc1.number1 + calc2.number1;
            c.number2 = calc1.number2 + calc2.number2;
            return c;

        }
        public void Print()
        {
            Console.WriteLine("NUmber 1 = " + number1);
            Console.WriteLine("Number2 = " + number2);

        }
    }
}
