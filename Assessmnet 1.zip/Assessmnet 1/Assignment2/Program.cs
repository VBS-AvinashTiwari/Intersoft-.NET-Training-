﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] Arr = { 1, 5, 2, 7, 6 };
            foreach (var item in Arr)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Deleted");
            var dele = Arr.Take(Arr.Length - 2).ToArray();
            foreach (var item in dele)
            {
                Console.WriteLine(item);

            }
            Console.WriteLine("Sort");
            Array.Sort(dele);
            foreach (var item in dele)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Min:" + dele.Min());
            Console.WriteLine("max:" + dele.Max());
            Console.WriteLine("SUM;" + dele.Sum());


        }

    }
}