﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_ADO_using_FOrm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectString = "Data Source=192.168.1.230;Initial Catalog=Freshers_Training2022;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022";
            SqlConnection myCOnnectioin = new SqlConnection();
            myCOnnectioin.ConnectionString = connectString;
            
            
            


            myCOnnectioin.Open();


            //creating a SQL string and Data adapter object
            string querystring = "Select * from Avinash_Employe";
            SqlDataAdapter mydataAdapter = new SqlDataAdapter(querystring, myCOnnectioin);
            // myCOnnectioin.Close();



            //creating fdataset and filling it
            DataSet dataset = new DataSet("Student1");
            //DataSet dataset = new DataSet("Avinash_Employe");
            //mydataAdapter.Fill(dataset, "Avinash_Employe");
            mydataAdapter.Fill(dataset);

            //Binding the Datagrid COntrol to Dataset

            dataGridView1.DataSource = dataset.Tables[0];
           // dataGridView2.DataSource = dataset.Tables[0];
           // myCOnnectioin.Dispose();

        }
    }
}
