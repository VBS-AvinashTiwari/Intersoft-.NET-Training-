﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_ADO_DOTNET
{
    class Program
    {
        static void Main(string[] args)
        {
            //Step 1: Creating a Connection 

            //Step 2: Creating Querystring 

            //Step 3: Opening Connection 

            //Step 4: Creating SQL Command 

            //Step 5: Reading Data using SQLDATAREADER class 
            string Connstring = "Data Source=192.168.1.230;Initial Catalog=Freshers_Training2022;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022";
            SqlConnection conn = new SqlConnection(Connstring);

            string querystring = " select * from Avinash_Employe";
            conn.Open();
            SqlCommand cmd = new SqlCommand(querystring, conn);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                for (int i= 0; i< reader.FieldCount;i++)
                {
                    Console.WriteLine(reader[i].ToString()  + " ");
                }
                Console.WriteLine("--");
            }
        }
    }
}
