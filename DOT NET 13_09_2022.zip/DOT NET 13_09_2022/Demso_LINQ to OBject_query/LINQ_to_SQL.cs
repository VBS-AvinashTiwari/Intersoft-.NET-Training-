﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq;
using System.Data.Linq.Mapping;
using System.Data.Linq;

namespace Demso_LINQ_to_OBject_query
{
    [Table(Name = "Person.Person")]
    public class Contact
    {
        [Column]
       public string titles;
        [Column]
        public string firstName;
        [Column]
        public string LastName;

    }
    public partial class LINQ_to_SQL : Form
    {
        public LINQ_to_SQL()
        {
            InitializeComponent();
        }

        private void LINQ_to_SQL_Load(object sender, EventArgs e)

        {
            
            //Connection string 
            string conn = "Data Source=192.168.1.230;Initial Catalog=AdventureWorks2017;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022";
            try
            {
                // creating Data Context
                DataContext db = new DataContext(conn);
                Table<Contact> contacts = db.GetTable<Contact>(); //Return the tbale of sdimilar type


                //Qurery DB
                var contactDetails =
                                        from c in contacts
                                        where c.titles == "Mr"
                                        orderby c.firstName
                                        select c;
                //Display Contact Details
                foreach (var c in contactDetails)
                {
                    //textBox1.AppendText(c.titles);
                    //textBox1.AppendText("\t");
                    textBox1.AppendText(c.firstName);
                    textBox1.AppendText("\t");
                    textBox1.AppendText(c.LastName);
                    textBox1.AppendText("\t");

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
