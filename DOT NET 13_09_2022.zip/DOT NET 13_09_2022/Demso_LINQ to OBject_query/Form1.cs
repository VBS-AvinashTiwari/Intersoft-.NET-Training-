﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demso_LINQ_to_OBject_query
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //DEFINING A string array
            string[] names = { "Rd Sharma",
                                "University Physics",
                                "Think RIch Grow More", 
                                "No need to waste time " };

            //LINQ Query

            IEnumerable<string> AlltimeFavBooks = from name in names
                                                  where name.Length > 5
                                                  select name;


            // for eacgh to display objects
            foreach (var name in AlltimeFavBooks)
            {
                richTextBox1.AppendText(name + "\n");

            }
        }
    }
}
