﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

//Checking current state of a thread ? 

namespace Assignment2
{
    class Program
    {
        public static void check()
        {
            Thread.Sleep(2000);
        }


        static void Main(string[] args)
        {
            Thread t1 = new Thread(new ThreadStart(check));

            Console.WriteLine("Threadstate of t1 thread is : {0}", t1.ThreadState);
            t1.Start();
            Console.WriteLine("Threadstate of t1 thread is : {0}",t1.ThreadState);
            Thread.Sleep(100);

            Thread t2 = new Thread(new ThreadStart(check));
            Console.WriteLine("Threadstate of t2 thread is : {0}", t2.ThreadState);
            t2.Start();
            Console.WriteLine("Threadstate of t2 thread is : {0}", t2.ThreadState);


        }
    }
}
