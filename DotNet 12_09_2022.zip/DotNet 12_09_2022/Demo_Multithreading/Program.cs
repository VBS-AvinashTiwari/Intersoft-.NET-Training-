﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Day9MultiThreading
{
    public class MyThread
    {
        public static void Thread1Display()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine($"First Thread \t" + i);
            }
        }

        public static void Thread2Display()
        {
            for (int i = 0; i < 3; i++)
            {

                Console.WriteLine("Second Thread in Execution \t" + i);
            }
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Multitreading in Action");

            MyThread obj1 = new MyThread(); //Creating an Object of our class 

            //Creating thread using thread class 
            //Thread thread1 = new Thread(new ThreadStart(obj1.Thread1Display));
            //thread1.Start();

            //Creating thread using thread class for calling no static method
            Thread a = new Thread(MyThread.Thread1Display);
            Thread b = new Thread(MyThread.Thread2Display);
            a.Start();
            b.Start();
            Console.WriteLine("Both Threads are running and executing corressponding process");

        }
    }
}
