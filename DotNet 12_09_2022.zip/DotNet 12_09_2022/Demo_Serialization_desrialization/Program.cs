﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Serialization_desrialization
{
   
    class Program
    {
        static void Main(string[] args)
        {
            Tutorial obj = new Tutorial();
            obj.ID = 1;
            obj.Name = "Asp .NET MVC";

            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream("C:\\Users\\Avinash Tiwari\\source\\repos\\Demo_Serialization_desrialization\\TextFile1.txt", FileMode.OpenOrCreate, FileAccess.Read);

            //serializimng the object
            formatter.Serialize(stream, obj);
            //Serialize the object
            Console.WriteLine("Objectss has been serialized");
            stream.Close();
            

            Stream stream1 = new FileStream("C:\\Users\\Avinash Tiwari\\source\repos\\Demo_Serialization_desrialization\\TextFile1.txt", FileMode.Open, FileAccess.Read);
            Tutorial objNew = (Tutorial)formatter.Deserialize(stream1);
            Console.WriteLine("Data after deserilaization is like ");
            Console.WriteLine(objNew.ID);
            Console.WriteLine(objNew.Name);
            stream1.Close();


        }
    }
}
