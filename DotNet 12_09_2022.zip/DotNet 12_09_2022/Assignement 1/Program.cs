﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


//  Define two Threads and check if it is alive or not ? 
namespace Assignement_1
{
    class Program
    {
        public static void check()
        {
            Thread.Sleep(1000);
        }
        static void Main(string[] args)
        {
            Thread t1 = new Thread(new ThreadStart(check)); // creating and intializing threads
            Thread t2 = new Thread(new ThreadStart(check));

            Console.WriteLine("Thread 1 is alive : {0}",t1.IsAlive); // display the current state of the thread is alivge property
            Console.WriteLine("Thread 2 is alive : {0}", t2.IsAlive);

            t1.Start();
            t2.Start();

        }
    }
}
