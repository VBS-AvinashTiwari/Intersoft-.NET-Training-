﻿using Microsoft.EntityFrameworkCore;
using Research_Travel_Award.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Research_Travel_Award.AvinashRepo
{
    public class AviRepo : Avi_Research
    {
        private readonly AdventureWorks2017Context _Context;

        public AviRepo(AdventureWorks2017Context Context)
        {
            _Context = Context;
        }

        public async Task<ResearchTravel> AddResearchTravels(ResearchTravel researchTravel)
        {
            var result = await _Context.ResearchTravel.AddAsync(researchTravel);

            await _Context.SaveChangesAsync();
            return result.Entity;

        }

        public async Task<ResearchTravel> DeleteResearchTravels(int Uid)
        {
            var result = await _Context.ResearchTravel.Where(x => x.Uid == Uid).FirstOrDefaultAsync();
            if (result != null)
            {
                _Context.ResearchTravel.Remove(result);
                await _Context.SaveChangesAsync();
                return result;
            }
            return null;

        }

        public async Task<IEnumerable<ResearchTravel>> GetResearchTravels()
        {
            return await _Context.ResearchTravel.ToListAsync();


        }

        public async Task<ResearchTravel> GetResearchTravels(int Uid)
        {
            return await _Context.ResearchTravel.FirstOrDefaultAsync(x => x.Uid == Uid);

        }

        public async Task<IEnumerable<ResearchTravel>> SearchResearchTravels(string name)
        {
            IQueryable<ResearchTravel> query = _Context.ResearchTravel;
            if (!string.IsNullOrEmpty(name))
            {
                query = query.Where(x => x.FirstName.Contains(name));
            }
            return await query.ToListAsync();

        }

        public async Task<ResearchTravel> UpdateResearchTravel(ResearchTravel researchTravel)
        {
            var result = await _Context.ResearchTravel.FirstOrDefaultAsync(x => x.Uid == researchTravel.Uid);
            if (result != null)
            {
                result.FirstName = researchTravel.FirstName;
                result.LastName = researchTravel.LastName;
                result.Email = researchTravel.Email;
                result.Address1 = researchTravel.Address1;
                result.Address2 = researchTravel.Address2;
                result.Country = researchTravel.Country;
                result.State = researchTravel.State;
                result.City = researchTravel.City;
                result.ZipCode = researchTravel.ZipCode;
                result.CostOfAirfare = researchTravel.CostOfAirfare;
                result.CostOfCareRental = researchTravel.CostOfCareRental;
                result.CostOfLodging = researchTravel.CostOfLodging;
                result.CostOfOtherGroundTransportation = researchTravel.CostOfOtherGroundTransportation;
                result.CostOfMileage = researchTravel.CostOfMileage;
                result.DescriptionOfOtherExpenses = researchTravel.DescriptionOfOtherExpenses;
                result.TotalExpenses = researchTravel.TotalExpenses;
                result.Subject = researchTravel.Subject;
                result.Institution = researchTravel.Institution;
                result.TravelStartDate = researchTravel.TravelStartDate;
                result.TravelEndDate = researchTravel.TravelEndDate;
                result.AppliedToOtherOrganization = researchTravel.AppliedToOtherOrganization;
                result.NameOfOrganization = researchTravel.NameOfOrganization;
                result.OtherAmountReceived = researchTravel.OtherAmountReceived;
                result.AdditionalComment = researchTravel.AdditionalComment;

                await _Context.SaveChangesAsync();
                return result;
            }
            return null;

        }
    }
}
