﻿using Research_Travel_Award.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Research_Travel_Award.AvinashRepo
{
   public interface Avi_Research
    {
        Task<IEnumerable<ResearchTravel>> SearchResearchTravels(string name);
        Task<IEnumerable<ResearchTravel>> GetResearchTravels();
        Task<ResearchTravel> GetResearchTravels(int Uid);
        Task<ResearchTravel> AddResearchTravels(ResearchTravel researchTravel);
        Task<ResearchTravel> UpdateResearchTravel(ResearchTravel researchTravel);
        Task<ResearchTravel> DeleteResearchTravels(int Uid);

    }
}
