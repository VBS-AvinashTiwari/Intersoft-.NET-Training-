﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Research_Travel_Award.Models
{
    public partial class AdventureWorks2017Context : DbContext
    {
        public AdventureWorks2017Context()
        {
        }

        public AdventureWorks2017Context(DbContextOptions<AdventureWorks2017Context> options)
            : base(options)
        {
        }

        public virtual DbSet<ResearchTravel> ResearchTravel { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("server=192.168.1.230;user=trainee2022;password=trainee@2022;database=AdventureWorks2017");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ResearchTravel>(entity =>
            {
                entity.HasKey(e => e.Uid)
                    .HasName("PK_UID");

                entity.Property(e => e.Uid).HasColumnName("UID");

                entity.Property(e => e.AdditionalComment).HasColumnName("Additional_Comment");

                entity.Property(e => e.Address1)
                    .HasColumnName("Address_1")
                    .HasMaxLength(100);

                entity.Property(e => e.Address2)
                    .HasColumnName("Address_2")
                    .HasMaxLength(100);

                entity.Property(e => e.AppliedToOtherOrganization).HasColumnName("Applied_To_Other_Organization");

                entity.Property(e => e.City).HasMaxLength(50);

                entity.Property(e => e.CostOfAirfare).HasColumnName("Cost_Of_Airfare");

                entity.Property(e => e.CostOfCareRental).HasColumnName("Cost_Of_CareRental");

                entity.Property(e => e.CostOfLodging).HasColumnName("Cost_of_Lodging");

                entity.Property(e => e.CostOfMileage).HasColumnName("Cost_Of_Mileage");

                entity.Property(e => e.CostOfOtherGroundTransportation).HasColumnName("Cost_Of_OtherGroundTransportation");

                entity.Property(e => e.Country).HasMaxLength(100);

                entity.Property(e => e.DescriptionOfOtherExpenses).HasColumnName("Description_Of_Other_Expenses");

                entity.Property(e => e.Email).HasMaxLength(100);

                entity.Property(e => e.FirstName)
                    .HasColumnName("first_name")
                    .HasMaxLength(20);

                entity.Property(e => e.Institution).HasMaxLength(40);

                entity.Property(e => e.LastName)
                    .HasColumnName("last_name")
                    .HasMaxLength(20);

                entity.Property(e => e.NameOfOrganization).HasColumnName("Name_Of_Organization");

                entity.Property(e => e.OtherAmountReceived).HasColumnName("Other_Amount_Received");

                entity.Property(e => e.State).HasMaxLength(20);

                entity.Property(e => e.Subject).HasMaxLength(30);

                entity.Property(e => e.TotalExpenses).HasColumnName("Total_Expenses");

                entity.Property(e => e.TravelEndDate).HasColumnName("Travel_End_Date");

                entity.Property(e => e.TravelStartDate).HasColumnName("Travel_Start_Date");

                entity.Property(e => e.ZipCode).HasColumnName("Zip_Code");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
