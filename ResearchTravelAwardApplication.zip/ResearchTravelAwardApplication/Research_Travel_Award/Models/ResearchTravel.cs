﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Research_Travel_Award.Models
{
    public partial class ResearchTravel
    {
        public int Uid { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public int ZipCode { get; set; }
        public float CostOfAirfare { get; set; }
        public float CostOfCareRental { get; set; }
        public float CostOfLodging { get; set; }
        public float CostOfOtherGroundTransportation { get; set; }
        public float CostOfMileage { get; set; }
        public float DescriptionOfOtherExpenses { get; set; }
        public float TotalExpenses { get; set; }
        public string Subject { get; set; }
        public string Institution { get; set; }
        public DateTime TravelStartDate { get; set; }
        public DateTime TravelEndDate { get; set; }
        public bool AppliedToOtherOrganization { get; set; }
        public string NameOfOrganization { get; set; }
        public bool OtherAmountReceived { get; set; }
        public string AdditionalComment { get; set; }
    }
}
