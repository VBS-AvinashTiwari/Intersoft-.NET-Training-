﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Research_Travel_Award.AvinashRepo;
using Research_Travel_Award.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Research_Travel_Award.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResearchTravelController : ControllerBase
    {
        private readonly Avi_Research _avi_Research;

        public ResearchTravelController(Avi_Research avi_Research)
        {
            _avi_Research = avi_Research;
        }
        [HttpGet]
        public async Task<ActionResult> GetResearchTravels()
        {
            try
            {
                return Ok(await _avi_Research.GetResearchTravels());
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error in Retrieving Data from Database");
            }

        }

        [HttpGet("{Uid:int}")]
        public async Task<ActionResult<ResearchTravel>> GetResearchTravels(int Uid)
        {
            try
            {
                var result = await _avi_Research.GetResearchTravels(Uid);
                if (result == null)
                {
                    return NotFound();
                }
                return result;
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error in Retrieving Data from Database");
            }

        }

        [HttpPost]
        public async Task<ActionResult<ResearchTravel>> CreateResearchTravels(ResearchTravel researchTravels)
        {

            try
            {
                if (researchTravels == null)
                {
                    return BadRequest();
                }
                var CreatedResearchTravel = await _avi_Research.AddResearchTravels(researchTravels);
                return CreatedAtAction(nameof(GetResearchTravels), new { Uid = CreatedResearchTravel.Uid }, CreatedResearchTravel);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error in Retrieving Data from Database");
            }
        }

        [HttpPut("{Uid:int}")]
        public async Task<ActionResult<ResearchTravel>> UpdateResearchTravel(int Uid, ResearchTravel researchTravel)
        {
            try
            {

                if (Uid != researchTravel.Uid)
                {
                    return BadRequest("Id Mismatch");
                }
                var researchtravelupdate = await _avi_Research.GetResearchTravels(Uid);
                if (researchtravelupdate == null)
                {
                    return NotFound($"Uid={Uid} not Found");
                }
                return await _avi_Research.UpdateResearchTravel(researchTravel);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error in Retrieving Data from Database");
            }
        }

        [HttpDelete("{Uid:int}")] 
        public async Task<ActionResult<ResearchTravel>> DeleteResearchTravels(int Uid)
        {
            try
            {

                var ResearchTravelsDelete = await _avi_Research.GetResearchTravels(Uid);
                if (ResearchTravelsDelete == null)
                {
                    return NotFound($"Uid={Uid} not Found");
                }
                return await _avi_Research.DeleteResearchTravels(Uid);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error in Retrieving Data from Database");
            }

        }

        [HttpGet("{search}")]
        public async Task<ActionResult<IEnumerable<ResearchTravel>>> SearchResearchTravels(string name)
        {
            try
            {
                var result = await _avi_Research.SearchResearchTravels(name);
                if (result.Any())
                {
                    return Ok(result);
                }
                return NotFound();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                     "Error in Retrieving Data from Database");
            }
        }

    }
}
