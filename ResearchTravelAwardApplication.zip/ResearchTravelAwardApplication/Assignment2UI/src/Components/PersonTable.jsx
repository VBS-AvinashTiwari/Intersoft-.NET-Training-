import React, { useState, useEffect } from 'react';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
import { useNavigate } from 'react-router-dom';
function PersonTable() {
  const [data, setData] = useState([]);
  const URL = 'https://localhost:44318/api/ResearchTravel';

  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  function handleDetails(e, i) {
    console.log(i);
    navigate('/details/' + i);
  }
  function handleEdit(e, i) {
    console.log(i);
    navigate('/edit/' + i);
  }

  function Delete(i) {
    const request = { method: 'DELETE' };
    fetch(URL + '/' + i, request)
      .then((response) => {
        return response.json();
      })
      .then((res) => {
        console.log('Delete Successful');
        fetchData();
      });
  }

  function handleDelete(e, i) {
    console.log('Delete Clicked' + i);

    confirmAlert({
      title: 'Confirm to Delete',
      buttons: [
        {
          label: 'Yes',
          onClick: () => {
            Delete(i);
          },
        },
        {
          label: 'No',
          onClick: () => {
            //fetchData();
          },
        },
      ],
    });
  }

  function navCreate(e) {
    navigate('/create');
  }
  const fetchData = () => {
    fetch(URL)
      .then(res => res.json())

      .then((response) => {
        const r = JSON.stringify(response);
        setData(JSON.parse(r));
       // console.log(data)
        console.log('Response ' + r);
      });
  };

  return (
    <>
      <h3 style={{ marginTop: '20px' }}>ResearchTravel</h3>

      <Button
        style={{ marginTop: '15px', marginBottom: '15px' }}
        onClick={(e) => navCreate(e)}
      >
        Create
      </Button>

      <div>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th> </th>
              <th>UId</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Country</th>
              <th>ResearchInstitution</th>
              <th>VisitingFrom</th>
              <th>VisitingTo</th>
              <th>TotalExpense</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {data.map((item, i) => (
              <tr key={item.uid}>
                <td>{i}</td>
                <td>{item.uid}</td>
                <td>{item.firstName}</td>
                <td>{item.lastName}</td>
                <td>{item.country}</td>
                <td>{item.institution}</td>
                <td>{item.travelStartDate}</td>
                <td>{item.travelEndDate}</td>
                <td>{item.totalExpenses}</td>
                <td>
                  <div>
                    <Button
                      variant="primary"
                      type="submit"
                      onClick={(e) => {
                        handleDetails(e, item.Uid);
                      }}
                    >
                      Details
                    </Button>

                    <> | </>
                    <Button
                      variant="warning"
                      type="submit"
                      onClick={(e) => {
                        handleEdit(e, item.Uid);
                      }}
                    >
                      Edit
                    </Button>

                    <> | </>
                    <Button
                      variant="danger"
                      type="submit"
                      onClick={(e) => {
                        handleDelete(e, item.Uid);
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </>
  );
}

export default PersonTable;
