import React, { useState, useEffect } from 'react';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { Form, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

function Edit() {
  let { id } = useParams();
  const URL = 'https://localhost:44318/api/ResearchTravel';
  const [firstName, setfirstName] = useState();
  const [lastName, setlastName] = useState();
  const [country, setcountry] = useState();
  const [researchInstitution, setresearchInstitution] = useState();
  const [visitingFrom, setvisitingFrom] = useState();
  const [visitingTo, setvisitingTO] = useState();
  const [totalExpense, settotalExpense] = useState();
  const [data, setData] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    fetch(URL + id)
      .then((res) => res.json())

      .then((response) => {
        const r = JSON.stringify(response);
        const res = JSON.parse(r);
        setData(JSON.parse(r));
        console.log('Response ' + data.first_name);
      });
  };

  function handleEdit(e) {
    console.log('ID ' + id);
    let firstName_, lastName_, Country_,researchInstitution_, visitingFrom_,visitingTo_,totalExpense_ ;
    if (firstName == null) {
      firstName_ = data.firstname;
    } else {
      firstName_ = firstName;
    }
    if (lastName == null) {
      lastName_ = data.last_name;
    } else {
      lastName_ = lastName;
    }
    if (country == null) {
      Country_ = data.Country;
    } else {
      Country_ = country;
    }
    if (researchInstitution == null) {
      researchInstitution_ = data.Institution;
    } else {
      researchInstitution_ = researchInstitution;
    }
    if (visitingFrom == null) {
      visitingFrom_ = data.Travel_Start_Date;
    } else {
      visitingFrom_ = visitingFrom;
    }
    if (visitingTo == null) {
      visitingTo_= data.Travel_End_Date;
    } else {
      visitingTo_ = visitingTo;
    }
    if (totalExpense == null) {
      totalExpense_ = data.Total_Expenses;
    } else {
      totalExpense_ = totalExpense;
    }

    if (firstName_ != null && lastName_ != null && Country_ != null && researchInstitution_ != null && visitingFrom_ != null && visitingTo_ != null && totalExpense_ != null ) {
      console.log(firstName + ' ' + lastName + ' ' + country+ ' ' + researchInstitution + ' '+ visitingFrom+ ' '+ visitingTo+' '+ totalExpense);
      e.preventDefault();
      try {
        fetch(URL + id, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            // first_Name: firstName,
            // last_Name: lastName,
            // address: address,
            //UID: uid,
            first_name: firstName_,
            last_name: lastName_,
            Country: Country_,
            Institution : researchInstitution_,
            Travel_Start_Date : visitingFrom_,
            Travel_End_Date : visitingTo_,
            Total_Expenses: totalExpense_
          }),
        });
      } catch (err) {
        console.log('ERRR' + err);
        alert(err);
      }
      navigate('/');
    } else {
      alert('Please fill all details');
    }
    navigate('/');
  }
  console.log(data.first_name +'hii')
  return (
    <div>
      <h3 style={{ marginTop: '15px', marginBottom: '15px' }}>
        Edit Form
      </h3>
      <Form>
        <Form.Group>
          <Form.Label>First Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter First Name"
            defaultValue={data.firstName}
            onChange={(e) => setfirstName(e.target.value)}
          />
        </Form.Group>

        <Form.Group>
          <Form.Label>Last Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter Last Name"
            defaultValue={data.lastName}
            onChange={(e) => setlastName(e.target.value)}
          />
        </Form.Group>

        <Form.Group>
          <Form.Label>country</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter country"
            defaultValue={data.country}
            onChange={(e) => setcountry(e.target.value)}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>researchInstitution</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter researchInstitution"
            defaultValue={data.institution}
            onChange={(e) => setresearchInstitution(e.target.value)}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>visitingFrom</Form.Label>
          <Form.Control
            type="date"
            placeholder="Enter Travel_Start_Date"
            defaultValue={data.travelStartDate}
            onChange={(e) => setvisitingFrom(e.target.value)}
          />
        </Form.Group> <Form.Group>
          <Form.Label>visitingTO</Form.Label>
          <Form.Control
            type="date"
            placeholder=" Enter visitingTo"
            defaultValue={data.travelEndDate}
            onChange={(e) => setvisitingTO(e.target.value)}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>totalExpense</Form.Label>
          <Form.Control
            type="textArea"
            placeholder="Enter totalExpense"
            defaultValue={data.otalExpenses}
            onChange={(e) => settotalExpense(e.target.value)}
          />
        </Form.Group>
        <div> </div>
        <Button
          style={{ marginTop: '15px', marginBottom: '15px' }}
          variant="primary"
          type="submit"
          onClick={(e) => handleEdit(e)}
        >
          Submit
        </Button>
      </Form>
    </div>
  );
}

export default Edit;
