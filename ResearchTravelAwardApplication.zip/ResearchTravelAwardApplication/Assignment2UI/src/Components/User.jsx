import React, { Component } from 'react'
import Service from './Service'

export default class user extends Component {

    constructor(props){
        super(props)
        this.state={
            user:[]
        }
    }

componentDidMount(){
    Service.getUser().then((res)=>{
        this.setState({user:res.data})
    });

}

  render() {
    return (
      <div>
        <h1>Personal Information</h1>
        <table className='table table-sprit'>
            <thead>
                <tr>
                    <td>UId</td>
                    <td>first_name</td>
                    <td>last_name</td>
                    <td>Email</td>
                            <td>Address_1</td>
                            <td>Address_</td>
                            <td>Country</td>
                            <td>State</td>
                            <td>City</td>
                            <td>Zip_Code</td>
                            <td>Subject</td>
                            <td>Institution</td>
                            <td>Travel_Start_Date</td>
                            <td>Travel_End_Date</td>
                            <td>Cost_Of_Airfare</td>
                            <td>Cost_Of_CareRental</td>
                            <td>Cost_of_Lodging</td>
                            <td>Cost_Of_OtherGroundTransportation</td>
                            <td>Cost_Of_Mileage</td>
                            <td>Description_Of_Other_Expenses</td>
                            <td>Total_Expenses</td>
                            <td>Applied_To_Other_Organization</td>
                            <td>Name_Of_Organization</td>
                            <td>Other_Amount_Received</td>
                            <td>Additional_Comment</td>
                   
                </tr>
            </thead>
            <tbody>
                {
                    this.state.user.map(
                        user =>
                            <tr key={user.uid}>
                            <td>{user.uid}</td>
                            <td>{user.firstName}</td>
                            <td>{user.lastName}</td>
                            <td>{user.email}</td>
                            <td>{user.address1}</td>
                            <td>{user.address2}</td>
                            <td>{user.country}</td>
                            <td>{user.state}</td>
                            <td>{user.city}</td>
                            <td>{user.zipCode}</td>
                            <td>{user.subject}</td>
                            <td>{user.institution}</td>
                            <td>{user.travelStartDate}</td>
                            <td>{user.travel_End_Date}</td>
                            <td>{user.costOfAirfare}</td>
                            <td>{user.costOfCareRental}</td>
                            <td>{user.costofLodging}</td>
                            <td>{user.costOfOtherGroundTransportation}</td>
                            <td>{user.costOfMileage}</td>
                            <td>{user.descriptionOfOtherExpenses}</td>
                            <td>{user.totalExpenses}</td>
                            <td>{user.appliedToOtherOrganization}</td>
                            <td>{user.NameOfOrganization}</td>
                            <td>{user.otherAmountReceived}</td>
                            <td>{user.additionalComment}</td>

                        </tr>
                        
                    )
                }
            </tbody>

        </table>
      </div>
    )
  }
}