import React, { useState, useEffect } from 'react';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import { Form, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

function Create() {
  const [uid, setUID] = useState();
  const [firstName, setfirstName] = useState();
  const [lastName, setlastName] = useState();
  const [country, setcountry] = useState();
  const [researchInstitution, setresearchInstitution] = useState();
  const [visitingFrom, setvisitingFrom] = useState();
  const [visitingTo, setvisitingTO] = useState();
  const [totalExpense, settotalExpense] = useState();
  const navigate = useNavigate();

  const URL = 'https://localhost:44318/api/ResearchTravel';
  function handleCreate(e) {
    if (firstName != null && lastName != null && country != null && researchInstitution != null && visitingFrom != null && visitingTo != null && totalExpense != null ) {
      console.log(firstName + ' ' + lastName + ' ' + country + ' ' + researchInstitution + ' '+ visitingFrom + ' '+ visitingTo +' '+ totalExpense + ' ');
      e.preventDefault();
      try {
        fetch(URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            UID: uid,
            first_name: firstName,
            last_name: lastName,
            Country: country,
            Institution : researchInstitution,
            Travel_Start_Date : visitingFrom,
            Travel_End_Date : visitingTo,
            Total_Expenses: totalExpense

          }),
        });
      } catch (err) {
        console.log('ERRR' + err);
        alert(err);
      }

      navigate('/');
      window.location.reload();
    } else {
      alert('Please fill all details');
    }
    navigate('/');
  }

  return (
    <div>
      <h3>Create</h3>
      <Form>
        <Form.Group>
          <Form.Label>First Name</Form.Label>
          <Form.Control
            type="textArea"
            placeholder="Enter First Name"
            onChange={(e) => setfirstName(e.target.value)}
          />
        </Form.Group>

        <Form.Group>
          <Form.Label>Last Name</Form.Label>
          <Form.Control
            type="textArea"
            placeholder="Enter Last Name"
            onChange={(e) => setlastName(e.target.value)}
          />
        </Form.Group>

        <Form.Group>
          <Form.Label>country</Form.Label>
          <Form.Control
            type="textArea"
            placeholder="Enter country"
            onChange={(e) => setcountry(e.target.value)}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>researchInstitution</Form.Label>
          <Form.Control
            type="textArea"
            placeholder="Enter researchInstitution"
            onChange={(e) => setresearchInstitution(e.target.value)}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>visitingFrom</Form.Label>
          <Form.Control
            type="date"
            placeholder="Enter visitingFrom"
            onChange={(e) => setvisitingFrom(e.target.value)}
          />
        </Form.Group> <Form.Group>
          <Form.Label>visitingTO</Form.Label>
          <Form.Control
            type="date"
            placeholder=" Enter visitingTo"
            onChange={(e) => setvisitingTO(e.target.value)}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>totalExpense</Form.Label>
          <Form.Control
            type="textArea"
            placeholder="Enter totalExpense"
            onChange={(e) => settotalExpense(e.target.value)}
          />
        </Form.Group>
        <div> </div>
        <Button
          style={{ marginTop: '15px' }}
          variant="primary"
          type="submit"
          onClick={(e) => handleCreate(e)}
        >
          Submit
        </Button>
      </Form>
    </div>
  );
}
export default Create;
