import React, {useState} from "react";
import './App.css';



const Form = () => {
  let initialState = {
    firstName: '',
    lastName: '',
    UID: '',
    Email:'',
    Address_1:'',
    Address_2:'',
    Country:'',
    State:'',
    Zip_Code:'',
    Subject_Of_Your_Research:'',
    Research_Instiatution_to_be_visited:'',
    Travel_Start_Date:'',
    Travel_End_Date:'',
    Cost_Of_Airfare:'',
    Cost_Of_Car_Rental:'',
    Cost_Of_Lodging:'',
    Cost_Of_Other_Ground_Transportation:'',
    Cost_Of_other_Expense:'',
    Description_Of_Other_Expense:'',
    TOTAL_EXPENSES:'',
    Name_Of_Organization:'',
    Other_amount_received:'',
    

  }
  
  const [formInputs, setFormInputs] = useState(initialState);
  return (
    <div className="container" style={{
      backgroundColor: "grey"
    }}>

      <div
        style={{
          backgroundColor: "skyblue",
          textAlign: "left",
          padding: "1% 1% 1% 6%",
        }}
        className="title"
      >
        <h1 style={{ margin: "0" }}>
          Disseration Research Travel Award Aplication
        </h1>
        <h3>UCLA Graduate Program in English</h3>
      </div>
      <div className="horizontal-1">
        <form
          style={{
            display: "flex",
            flexFlow: "column wrap",
            padding: "1% 2% 0 6%",
          }}
        >
          <h2 style={{ textAlign: "left", paddingLeft: "3%" }}>
            Personal Information:
          </h2>

          <div style={{ paddingLeft: "15%" }}>
            <div>
              <p className="para">First Name: </p>
              <input
                className="form-input"
                type="text"
                name="fname"
                value={formInputs.firstName}
                onChange={(e)=>setFormInputs({...formInputs, firstName: e.target.value})} 
                required
              />

              <p
                style={{ marginRight: "10px", marginLeft: "20%" }}
                className="para"
              >
                Last Name:
              </p>
              <input className="form-input" type="text" name="lname" value={formInputs.lastName}
                onChange={(e)=>setFormInputs({...formInputs, lastName: e.target.value})}
                required />
            </div>
            <div>
              <p className="para">UID:</p>
              <input className="form-input" type="text" name="UID" value={formInputs.UID}
              onChange={(e)=>setFormInputs({...formInputs, UID: e.target.value})}
              required />
              <p
                className="para"
                style={{ marginRight: "10px", marginLeft: "20%" }}
              >
                Email:
              </p>
              <input className="form-input" type="text" name="EmailID" value={formInputs.Email}
              onChange={(e)=>setFormInputs({...formInputs, Email: e.target.value})}
              required />
            </div>
            <div>
              <p className="para">Address_1:</p>
              <input className="form-input" type="text" name="Address_1"value={formInputs.Address_1}
              onChange={(e)=>setFormInputs({...formInputs, Address_1: e.target.value})}
              required />
            </div>
            <div>
              <p className="para">Address_2:</p>
              <input
                className="form-input"
                type="text"
                name="Address_2"
                value={formInputs.Address_2}
              onChange={(e)=>setFormInputs({...formInputs, Address_2: e.target.value})}
              required
              
              />
            </div>
            <div>
              <p className="para">Country:</p>
              {/* <input className="form-input" type="text" name="" value="" /> */}
              {<select>
                <option>Select....</option>
               <option>India</option>
               <option>Sahara</option>
               <option>Desi</option>
               
              </select>
              }
              
              {/* </div>
          <div> */}
              <p
                className="para"
                style={{ marginRight: "10px", marginLeft: "40%" }}
              >
                State:
              </p>
              {/* <input className="form-input" type="text" name="" value="" /> */}
              {<select>
                <option>Select....</option>
               <option>Uttarakhand</option>
               <option>UttarPradesh</option>
               <option>Delhi</option>
              </select>}
             
            </div>
            <div>
              <p className="para">Zip Code:</p>
              <input className="form-input" type="text" name="ZIP_Code" value={formInputs.Zip_Code}
              onChange={(e)=>setFormInputs({...formInputs, Zip_Code: e.target.value})}
              required />
            </div>
          </div>

          <hr />

          <div className="horizontal-2">
            <h2 style={{ textAlign: "left", paddingLeft: "3%" }}>
              Research Information:
            </h2>

            <div style={{ paddingLeft: "15%" }}>
              <div>
                <p className="para">Subject of your research: </p>
                <textarea
                  className="form-input"
                  type="text"
                  name="Subject_Of_Your_Research"
                  value={formInputs.Subject_Of_Your_Research}
              onChange={(e)=>setFormInputs({...formInputs, Subject_Of_Your_Research: e.target.value})}
              
                  textarea
                />
              </div>
              <div>
                <p className="para">Research Instiatution to be visited:</p>
                <input className="form-input" type="text" name="Research_Instiatution_to_be_visited" value={formInputs.Research_Instiatution_to_be_visited}
              onChange={(e)=>setFormInputs({...formInputs, Research_Instiatution_to_be_visited: e.target.value})}
              required />
              </div>
              <div>
                <p className="para">Travel Start Date:</p>
                <input className="form-input" type="date" name="Travel_Start_Date"  value={formInputs.Travel_Start_Date}
              onChange={(e)=>setFormInputs({...formInputs, Travel_Start_Date: e.target.value})}
              required />
              </div>
              <div>
                <p className="para">Travel End Date:</p>
                <input className="form-input" type="date" name="Travel_End_Date" value={formInputs.Travel_End_Date}
              onChange={(e)=>setFormInputs({...formInputs, Travel_End_Date: e.target.value})}
              required />
              </div>
              <div>
                {/* <p className="para">Addres 2:</p>
                <input
                  className="form-input"
                  type="text"
                  name=""
                  value=""
                  required
                /> */}
              </div>
            </div>
          </div>
          <hr />

          <div className="horizontal-3">
            <h2
              style={{
                textAlign: "left",
                marginBottom: "0",
                paddingTop: "0",
                margin: "0",
                paddingLeft: "3%",
              }}
            >
              Expense Information:
            </h2>
            <p style={{ paddingLeft: "3%" }}>
              (Transportation, Lodging, Conference,Registration Only - Actual or
              Estimated)
            </p>
            <div style={{ paddingLeft: "15%" }}>
              {/* <div>
                <p className="para">Subject of your research: </p>
                <textarea className="form-input" type="text" name="" value="" />
              </div> */}
              <div>
                <p className="para">Cost of Airfare:</p>
                <input className="form-input" type="text" name="Cost_Of_Airfare" value={formInputs.Cost_Of_Airfare}
              onChange={(e)=>setFormInputs({...formInputs, Cost_Of_Airfare: e.target.value})}
                />
              </div>
              <div>
                <p className="para">Cost of Car Rental:</p>
                <input className="form-input" type="text" name="Cost_Of_Car_Rental" value={formInputs.Cost_Of_Car_Rental}
              onChange={(e)=>setFormInputs({...formInputs, Cost_Of_Car_Rental: e.target.value})}
              />
              </div>
              <div>
                <p className="para">Cost of Lodging:</p>
                <input className="form-input" type="text" name="Cost_Of_Lodging" value={formInputs.Cost_Of_Lodging}
              onChange={(e)=>setFormInputs({...formInputs, Cost_Of_Lodging: e.target.value})}
              />
              </div>
              <div>
                <p className="para">Cost of other Ground Transportation:</p>
                <input className="form-input" type="text" name="Cost_Of_Other_Ground_Transportation" value={formInputs.Cost_Of_Other_Ground_Transportation}
              onChange={(e)=>setFormInputs({...formInputs, Cost_Of_Other_Ground_Transportation: e.target.value})}
              />
              </div>
              <div>
                <p className="para">Cost of other Expense(s):</p>
                <input className="form-input" type="text" name="Cost_Of_other_Expense" value={formInputs.Cost_Of_other_Expense}
              onChange={(e)=>setFormInputs({...formInputs, Cost_Of_other_Expense: e.target.value})} />
              </div>
              <div>
                <p className="para">Description of other Expense(s):</p>
                <textarea
                  className="form-input"
                  type="textarea"
                  rows="5"
                  cols="20"
                  name="Description_Of_Other_Expense"
                  value={formInputs.Description_Of_Other_Expense}
              onChange={(e)=>setFormInputs({...formInputs, Description_Of_Other_Expense: e.target.value})} />
              </div>
              <div>
                <p className="para">TOTAL EXPENSES:</p>
                <input className="form-input" type="text" name="TOTAL_EXPENSES" value={formInputs.TOTAL_EXPENSES}
              onChange={(e)=>setFormInputs({...formInputs, TOTAL_EXPENSES: e.target.value})} />
              </div>
            </div>
          </div>
          <hr />

          <div className="horizontal-4">
            <h2 style={{ textAlign: "left", paddingLeft: "3%" }}>
              Additional Information:
            </h2>
            <div style={{ paddingLeft: "15%" }}>
              <div style={{ display: "flex", flexFlow: "row wrap" }}>
                <p className="para">
                  I have applied to another organization for funding
                </p>
                <div
                  style={{
                    display: "flex",
                    flexFlow: "column wrap",
                    justifyContent: "space-evenly",
                  }}
                >
                  <div style={{ display: "flex", flexFlow: "row wrap" }}>
                    <input
                      id="funding-yes"
                      name="funding"
                      type="radio"
                      value="Yes"
                    />
                    <label htmlFor="funding-yes">Yes</label>
                  </div>

                  <div style={{ display: "flex", flexFlow: "row wrap" }}>
                    <input
                      id="funding-no"
                      name="funding"
                      type="radio"
                      value="No"
                    />
                    <label htmlFor="funding-no">No</label>
                  </div>
                </div>
              </div>
              <div>
                <p className="para">Name of Organization</p>
                <input className="form-input" type="text" value={formInputs.Name_Of_Organization}
              onChange={(e)=>setFormInputs({...formInputs, Name_Of_Organization: e.target.value})} />
              </div>
              <div style={{ display: "flex", flexFlow: "row wrap" }}>
                <p className="para">Funding received?</p>
                <div
                  style={{
                    display: "flex",
                    flexFlow: "column wrap",
                    justifyContent: "space-evenly",
                  }}
                >
                  <div style={{ display: "flex", flexFlow: "row wrap" }}>
                    <input
                      id="funding-yes"
                      name="funding"
                      type="radio"
                      className="form-input"
                      value="Yes"
                      onChange={(e)=>setFormInputs({...formInputs, Other_Amount_Received: e.target.value})} 
                    />
                    <label htmlFor="funding-yes">Yes</label>
                  </div>
                  <div style={{ display: "flex", flexFlow: "row wrap" }}>
                    <input
                      id="funding-no"
                      name="funding"
                      className="form-input"
                      type="radio"
                      value="No"
                      onChange={(e)=>setFormInputs({...formInputs, Other_Amount_Received: e.target.value})}
                    />
                    <label htmlFor="funding-no">No</label>
                  </div>
                  <div style={{ display: "flex", flexflow: "row wrap" }}>
                    <input
                      id="funding-no"
                      name="funding"
                      className="form-input"
                      type="radio"
                      value="No"
                      onChange={(e)=>setFormInputs({...formInputs, Other_Amount_Received: e.target.value})}
                    />
                    <label htmlFor="funding-no">Don't know yet</label>
                  </div>
                </div>
              </div>

              <div style={{ display: "flex", flexFlow: "row wrap" }}>
                <p className="para">Other amount received</p>

                <input className="form-input" type="text" name="Other_amount_received" value={formInputs.Other_amount_received}
              onChange={(e)=>setFormInputs({...formInputs, Other_amount_received: e.target.value})} />
              </div>
              <div>
                <p className="para">
                  Note:
                  hhcsjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj
                </p>
              </div>
              <div style={{ display: "flex", flexFlow: "row wrap" }}>
                <p className="para">Additional comments</p>

                <textarea
                  className="form-input"
                  name=""
                  id=""
                  cols="30"
                  rows="5"
                ></textarea>
              </div>
            </div>
          </div>
        </form>
        <div
          className="footer"
          style={{
            paddingTop: "10px",
            paddingLeft: "40px",
            // paddingTop: "10px",
          }}
        >
          <div>

      <form onsubmit="console.log('You clicked submit.'); return false">
  <button type="submit">Submit</button>
</form>
    
          </div>
          <div>
              <form onsubmit="console.log('You clicked Reset.'); return false">
  <button type="submit">Reset</button>
</form>
          </div>
          <div>
          <form onsubmit="console.log('You clicked END.'); return false">
  <button type="submit">END</button>
</form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Form;
