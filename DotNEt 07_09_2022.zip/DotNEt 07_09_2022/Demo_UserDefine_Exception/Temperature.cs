﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo_UserDefine_Exception
{
    public class TempIsZeroException : Exception
    {
        public TempIsZeroException(string message) : base(message)
        {
            //this.Message = message;

        }
    }
    class Temperature
    {
        int temperature = 0;
        public void showTemp()
        {
            if (temperature == 0)
            {
                throw (new TempIsZeroException("Zero Temperature Found"));
            }
            else
            {
                Console.WriteLine("Temperature:{0}", temperature);
            }
        }
    }
}
