﻿using System;

namespace Demo_UserDefine_Exception
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("User Defined Exception");

            Temperature temp = new Temperature();

            try
            {
                temp.showTemp();

            }
            catch (TempIsZeroException e)
            {
                Console.WriteLine("Temperature is Zero Exception", e.Message);
                //throw;
            }
        }
    }
}
