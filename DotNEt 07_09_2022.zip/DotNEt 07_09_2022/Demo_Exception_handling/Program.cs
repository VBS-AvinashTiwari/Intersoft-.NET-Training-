﻿using System;

namespace Demo_Exception_handling
{
    class Program : System.Exception
    {
        int Age;
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            int[] arr = { 1, 2, 3 ,6 };

            //Displayin it
         

            try
            {
                for (int i = 0; i < arr.Length; i++)
                {
                    Console.WriteLine(arr[i]);
                }

                Console.WriteLine(arr[3]);

            }
            catch(IndexOutOfRangeException e)
            {
                Console.WriteLine("An exception has occurs;{0},{1}", e.Message,e.StackTrace);

                //throw;
            }

            catch(DivideByZeroException e)
            {
                Console.WriteLine("An exception has occured :{0}", e.Message);

            }

            finally
            {
                Console.WriteLine("Finally blocks runs irrespective of Exception!!");
                for (int i=0; i < arr.Length; i++)
                {
                    Console.WriteLine("{0}",arr[i]);
                }
            }
        }
    }
}
