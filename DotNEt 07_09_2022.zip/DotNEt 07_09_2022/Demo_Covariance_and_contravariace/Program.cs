﻿using System;

namespace Demo_Covariance_and_contravariace
{
    class Program
    {
        static string GetString()
        {
            return "Sample text";
        }
        static void Setobject(object val1)
        {

        }

        static void Setstring(object val2)
        {

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Covariance and contravariance");
            Console.WriteLine("Array data types support Covariance");
            object[] objArray = new string[10];
            //here we are assigning a string array to an object array variable

            objArray[0] = "12";
            Console.WriteLine(objArray[0]);

            Console.WriteLine("Delegates Covariance..!!!");
            Func<object> delegateobj = GetString;
            //here a string returning function is being assigned
            //to delegate which is declared to return object type

            Func<string> del3 = GetString;
            Func<object> del4 = del3;// implicit conversion between generic delegates only possible after .net4 version


            //String strobj = delegateobj.ToString();
            //Console.WriteLine(strobj);

            Console.WriteLine("Contravaraince Delegate reverses the Covariance functionality");
            Action<string> del2 = Setobject;
            


            




        }
    }
}
