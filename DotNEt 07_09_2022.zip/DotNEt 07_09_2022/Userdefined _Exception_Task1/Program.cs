﻿using System;

namespace Userdefined__Exception_Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Age Validation!!!!!!!");
            Age age = new Age();

            try
            {
                age.showAge(19);
            }
            catch (InvalidAgeException ag)
            {
                Console.WriteLine("Age is Invalid",ag.Message);

                //throw;
            }
        }
    }
}
