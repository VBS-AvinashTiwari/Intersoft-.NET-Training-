﻿using System;

namespace Demo_Anonyms_function_Delegation_Method
{
    public delegate void mydelegate();
    class Program
    {

        static  void Main(string[] args)
        {
            Console.WriteLine("Implementing Anonymous delegate Method");
            mydelegate del1 = delegate()
                {
                Console.WriteLine("Anonymous Delegate Method!!!!!!!");
                };

            del1();

        }
    }
}
