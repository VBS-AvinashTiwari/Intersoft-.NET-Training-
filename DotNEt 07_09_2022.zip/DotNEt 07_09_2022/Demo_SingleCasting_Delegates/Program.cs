﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6Delegate
{
    class Myprogram
    {
        public delegate void delmethod();

        internal class Program
        {
            public static void display()
            {
                Console.WriteLine("Inside Display()");
            }
            public static void print()
            {
                Console.WriteLine("We are inside print()");
            }
            public static void show()
            {
                Console.WriteLine("Inside Show()");
            }
            public void print1()
            {
                Console.WriteLine("Inside print1()");
            }
            static void Main(string[] args)
            {
                Console.WriteLine("Single Casting Delegates..!!");

                delmethod del1 = Program.show;

                delmethod del2 = new delmethod(Program.display);
                delmethod del3 = new delmethod(Program.print);


                Program obj1 = new Program();

                delmethod del4 = obj1.print1;

                del1();
                del2();
                del3();
                del4();
            }
        }
    }
}