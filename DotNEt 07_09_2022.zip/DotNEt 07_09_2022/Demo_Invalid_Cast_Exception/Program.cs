﻿using System;

namespace Demo_Invalid_Cast_Exception
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Invalid Case Exception");
            int i = 123;
            string s = " I am feeling Lucky";
            object obj = s; // object consist string

            try
            {
                i = (int)obj;
                Console.WriteLine(" This writeline is at the end of try block");

            }

            catch (Exception ex)
            {
                Console.WriteLine(" catching the {0} exception trigger the finally blocks", ex.GetType());
                throw;
            }
            finally
            {
                Console.WriteLine("Excuting the finally blocks...!!!");
                Console.WriteLine("i= {0}",i);
            }

            
        }
    }
}
