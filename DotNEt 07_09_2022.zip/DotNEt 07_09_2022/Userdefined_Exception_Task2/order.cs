﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Userdefined__Exception_Task1
{

    public class InvalidOrderException : Exception
    {
        public InvalidOrderException(String message) : base(message)
        {

        }
    }
    class Order
    {
        int order = 0;
        public void showOrder(int order)
        {
            if (order > 5)
            {
                throw (new InvalidOrderException("order must be greater than 5"));
            }
            else
            {
                Console.WriteLine("order  is invalid");
            }
        }


    }
}