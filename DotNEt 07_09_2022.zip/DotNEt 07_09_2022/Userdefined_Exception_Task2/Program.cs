﻿using System;

namespace Userdefined__Exception_Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Order Validation!!!!!!!");
            Order order = new Order();
            try
            {
                order.showOrder(4);
                //Console.WriteLine(("Age is valid",);
            }
            catch (InvalidOrderException ord)
            {
                Console.WriteLine("Order is Invalid", ord.Message);

                //throw;
            }
        }
    }
}