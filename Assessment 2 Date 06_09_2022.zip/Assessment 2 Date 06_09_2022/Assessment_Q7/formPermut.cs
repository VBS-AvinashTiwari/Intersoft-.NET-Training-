﻿using System;

namespace Assessment_Q7
{
    internal class formPermut
    {
        internal void prnPermut(int[] arr1, int v1, int v2)
        {
            throw new NotImplementedException();
        }
    }
}