﻿using System;

namespace Assessment
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[10];
            int i, num, sum = 0;


            Console.Write("Input the number of elements to be stored in the array :");
            num = Convert.ToInt32(Console.ReadLine());

            Console.Write("Input {0} elements in the array :\n", num);
            for (i = 0; i < num; i++)
            {
                Console.Write("element - {0} : ", i);
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (i = 0; i < num; i++)
            {
                sum += arr[i];
            }

            Console.Write("Sum of all elements stored in the array is : {0}\n\n", sum);

        }
    }
}
