﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8Destructor
{
    class Complex
    {
        int real, imaginary;

        public Complex()
        {

            real = 0;
            imaginary = 0;
        }
        public void SetValue(int r, int i)
        {
            real = r;
            imaginary = i;
        }
        public void DisplayValue()
        {
            Console.WriteLine("real =" + real);
            Console.WriteLine("imaginary =" + imaginary);

        }
        ~Complex()
        {
            Console.WriteLine("Destructor was called");
        }
    }
}