﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Deep_Copy_AND_Shallow_Copy
{
    class Shallow_Copy : ICloneable
    {
        public int I { get; set; }
        public int J { get; set; }

        public object Clone()
        {
            return this.MemberwiseClone();

            
        }
    }
}
