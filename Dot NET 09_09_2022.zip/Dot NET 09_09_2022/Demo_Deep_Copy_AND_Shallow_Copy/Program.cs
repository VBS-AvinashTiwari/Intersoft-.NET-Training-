﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Deep_Copy_AND_Shallow_Copy
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Deep copying taking place As memeory ref is same");
            Shallow_Copy obj = new Shallow_Copy();
            Shallow_Copy objClone = obj;
            obj.I = 101; // setting obj value after cloning
            Console.WriteLine("Objvalue:{0}\t clone value ;{1}", obj.I, objClone.I);

            Shallow_Copy obj2 = (Shallow_Copy)obj.Clone();
            obj.I = 201;
            Console.WriteLine("After using memberWise clone(){0}", obj2.I);

        }
    }
}
