﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_File_Handling
{
    class File_Write
    {
        public void WriteData()
        {
            //Step1 : Creationg object of File Stream For writing into a file
            // Step2 : Creating the object of stream writer and passing file stream object as parameter
            // Step3 : Asking user for the text message and saying it to Stream Writer Object
            // step4: Closing stream Writer and file stream using CLose()

            FileStream fs = new FileStream("C:\\Users\\Avinash Tiwari\\Desktop\\.NET Training\\Dot NET 09_09_2022\\Demo_File_Handling\\Mydetails.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            Console.WriteLine("Enter the Text...");
            String str = Console.ReadLine();
            sw.WriteLine("\n"+str);
            sw.Flush();
            sw.Close();
            fs.Close();
        }

        public void readData()
        {
            FileStream fs = new FileStream("C:\\Users\\Avinash Tiwari\\Desktop\\.NET Training\\Dot NET 09_09_2022\\Demo_File_Handling\\Mydetails.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            String str = sr.ReadToEnd();
            Console.WriteLine(str);
            
            sr.Close();
            fs.Close();
        }

    }
}
