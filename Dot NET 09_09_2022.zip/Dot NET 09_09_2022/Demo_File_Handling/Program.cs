﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_File_Handling
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with streams -- Sequence of Byte ");

            File_Write wr = new File_Write();
            wr.WriteData();
            Console.WriteLine("Reading data from the file");
            wr.readData();


           
            
        }
    }
}
