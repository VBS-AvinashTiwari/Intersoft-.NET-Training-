﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Objectpooling
{
    class Program
    {
        static void Main(string[] args)
        {
            Factory fa = new Factory();
            Employee myEmp = fa.GetEmployee();
            Console.WriteLine("FIrst Object is created");
            Employee myemp1 = new Employee();
            Console.WriteLine("Second object is created");
            Employee myemp2 = new Employee();
            Console.WriteLine("Third Object is created");
        }
    }
}
