﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment2_Windows_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "+";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "6";
        }

        private void button18_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "0";
        }

        private void btnDOT_Click(object sender, EventArgs e)
        {
            string w = richTextBox1.ToString();
            int len = w.Length;
            if (richTextBox1.Text[--len] != '.')
            {
                richTextBox1.Text += ".";
            }
        }

        private void btnequal_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable Calc = new DataTable();
                var ans = Calc.Compute(richTextBox1.Text, "");
                richTextBox1.Text = ans.ToString();
            }

            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "5";
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "*";
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "/";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "9";
        }

        private void btnBackspace_Click(object sender, EventArgs e)
        {
            int length = richTextBox1.TextLength - 1;
            string text = richTextBox1.Text;
            richTextBox1.Clear();
            for (int i = 0; i < length; i++)
            {
                richTextBox1.Text = richTextBox1.Text + text[i];
            }
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + "-";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }

   

}

