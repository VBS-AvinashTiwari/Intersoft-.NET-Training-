﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_ArrayList_Non_Generic_Collection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Array List Implementation - Non generic Collection");

            ArrayList myfav = new ArrayList();
            myfav.Add("Dell - latitude");
            myfav.Add(true);
            myfav.Add('P');
            myfav.Add(22);
            myfav.Add(2.14);
            myfav.Add(25.22D);
            myfav.Add('P');
            myfav.Add(22);
            myfav.Add(2.14);
            myfav.Add(25.22D);



            Console.WriteLine(myfav.Capacity);
            Console.WriteLine(myfav.Count);

            foreach ( var item in myfav) 
            {
                Console.WriteLine(item);
            }
            //myfav.Sort();//Will raise exception

            

            myfav.Reverse();

            foreach (var item in myfav)
            {
                Console.WriteLine(item);
            }
        }
    }
}
