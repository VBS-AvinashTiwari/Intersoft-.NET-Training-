﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_IF_ELSE_Condition
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with IF_ELSE Condition");

            Console.WriteLine("Enter Your Age");
            int age = Convert.ToInt32(Console.ReadLine());

            if (age >=18)
            {
                Console.WriteLine(" You are  Eligible for voting rights in India ..!!");
            }
            else
            {
                Console.WriteLine("Watch Cartoon and Play inside Home ...!!");
            }
        }
    }
}
