﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Date_Time
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with Date and Time In C#");
            DateTime todaysDate = new DateTime(2022,09,01,10,30,45);
            Console.WriteLine(todaysDate.Year);
            Console.WriteLine(todaysDate.Month);
            Console.WriteLine(todaysDate.Day);
            Console.WriteLine("------------------Displaying Time Details--------------------");

            Console.WriteLine(todaysDate.Hour);
            Console.WriteLine(todaysDate.Minute);
            Console.WriteLine(todaysDate.Second);

            Console.WriteLine(todaysDate.DayOfWeek);

            Console.WriteLine(todaysDate.ToString("MMMM dd, yyyy"));
            Console.WriteLine(todaysDate.ToString("MM dddd, yyyy"));

            Console.WriteLine(DateTime.Now);
            Console.WriteLine(DateTime.MinValue);
            Console.WriteLine(DateTime.MaxValue);



        }
    }
}
