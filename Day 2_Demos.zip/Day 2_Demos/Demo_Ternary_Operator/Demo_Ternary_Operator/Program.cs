﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Ternary_Operator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ternary/ Conditional Operator");
            int x = 20, y ;
            var result = x > y ? " X is greater than Y" :
                            x < y ? " X is less than Y" :
                                x == y ? " X is equal to y " : " No Result" ;
            Console.WriteLine(result);
        }
    }

}